# Business Requirements Document

## Pizza Order Sales Analytics

Phiên bản 2.0  
Loại dự án: dự án cá nhân  
Vai trò thực hiện: Business Analyst và Data Analyst  
Công cụ: Excel, SQL Server, Power BI và UAT.

## 1. Bối cảnh nghiệp vụ

Cửa hàng pizza có dữ liệu chi tiết từng món trong đơn hàng nhưng chưa có một báo cáo thống nhất để theo dõi doanh thu, số đơn, số lượng bán và hiệu suất sản phẩm. Khi mỗi chỉ số được tính riêng, người xem có thể dùng khác phạm vi ngày, đếm số dòng thay cho số đơn hoặc đưa ra nhận xét không được dữ liệu hỗ trợ.

Dự án xây dựng một báo cáo bán hàng gồm hai trang. Trang Home theo dõi KPI, xu hướng thời gian và cơ cấu doanh thu. Trang Best/Worst Sellers so sánh sản phẩm theo doanh thu, số lượng và số đơn.

Đây là tình huống mô phỏng cho portfolio. Các vai trò cửa hàng được dùng để xác định nhu cầu và tiêu chí chấp nhận, không đại diện cho phỏng vấn stakeholder thực tế.

## 2. Bài toán cần giải quyết

Báo cáo cần trả lời các câu hỏi:

- Cửa hàng tạo ra bao nhiêu doanh thu trong kỳ?
- Có bao nhiêu đơn hàng và bao nhiêu pizza đã bán?
- Giá trị trung bình mỗi đơn và số pizza trung bình mỗi đơn là bao nhiêu?
- Số đơn thay đổi như thế nào theo thứ và theo tháng?
- Danh mục và kích cỡ nào đóng góp nhiều doanh thu nhất?
- Danh mục nào bán nhiều pizza nhất?
- Những sản phẩm nào thuộc Top 5 và Bottom 5 theo doanh thu, số lượng và số đơn?
- Kết quả thay đổi như thế nào khi người xem chọn khoảng ngày hoặc danh mục?

## 3. Mục tiêu

- Chuẩn hóa công thức cho 5 KPI bán hàng.
- Tạo một nguồn đối chiếu SQL cho toàn bộ biểu đồ Power BI.
- Hỗ trợ quản lý xem xu hướng bán hàng theo thời gian.
- Phân biệt sản phẩm dẫn đầu về doanh thu, số lượng và số đơn.
- Kiểm tra tính chính xác của dashboard bằng test case và bằng chứng.

Dự án không đặt mục tiêu chứng minh mức tăng doanh thu hoặc hiệu quả của một quyết định kinh doanh vì chưa có dữ liệu trước–sau và chưa triển khai hành động thực tế.

## 4. Người sử dụng và nhu cầu

### Quản lý cửa hàng

Cần xem nhanh tình hình bán hàng, xác định thời điểm có nhiều đơn và nhận diện các nhóm sản phẩm cần phân tích thêm.

### Người phân tích dữ liệu

Cần công thức KPI thống nhất, bộ lọc rõ ràng và truy vấn SQL có thể lặp lại để kiểm tra báo cáo.

### Người kiểm thử

Cần tiêu chí chấp nhận, dữ liệu đối chiếu và cách ghi nhận Pass, Fail, Blocked hoặc Not Run.

Trong dự án cá nhân, một người thực hiện cả ba nhóm công việc. UAT được ghi là tự kiểm thử và không thay thế xác nhận của người dùng nghiệp vụ thực tế.

## 5. Phạm vi

### Trong phạm vi

- Năm KPI: Total Revenue, Avg Order Value, Total Pizzas Sold, Total Orders và Avg Pizzas Per Order.
- Xu hướng số đơn theo thứ và tháng.
- Tỷ trọng doanh thu theo danh mục và kích cỡ.
- Số pizza bán theo danh mục.
- Top 5 và Bottom 5 sản phẩm theo doanh thu, số lượng và số đơn.
- Bộ lọc khoảng ngày và danh mục.
- Đối chiếu Excel, SQL Server và Power BI.
- Kịch bản UAT cho KPI, biểu đồ, bộ lọc và giao diện.

### Ngoài phạm vi

- Tạo, sửa hoặc hủy đơn hàng.
- Thanh toán, giao hàng và quản lý khách hàng.
- Quản lý tồn kho và nguyên liệu.
- Chi phí, lợi nhuận và biên lợi nhuận.
- Quảng cáo, lượt truy cập, tỷ lệ chuyển đổi và ROAS.
- Dự báo doanh thu hoặc nhu cầu.
- Vận hành gian hàng trên sàn thương mại điện tử.
- Phân quyền và triển khai Power BI Service.

## 6. Dữ liệu sử dụng

Nguồn dữ liệu là file `pizza_sales_excel_file.xlsx`, sheet `pizza_sales`, và bảng SQL Server `dbo.pizza_sales`.

- Thời gian: 01/01/2015 đến 31/12/2015.
- Số dòng chi tiết: 48.620.
- Số đơn duy nhất: 21.350.
- Số cột: 12.
- Mức chi tiết: một dòng món trong đơn hàng.
- Khóa dòng: `pizza_id`.
- Khóa đơn: `order_id`.

Các cột chính gồm ngày, giờ, mã đơn, tên pizza, danh mục, kích cỡ, số lượng, đơn giá và thành tiền. Không phát hiện ô trống, `pizza_id` trùng, số lượng không dương hoặc giá âm trong file đã kiểm tra.

Đơn vị tiền tệ chưa được xác nhận trong nguồn. Báo cáo không được tự gán USD hoặc VNĐ cho đến khi có thông tin nguồn chính thức.

## 7. User stories

### US01 Theo dõi KPI

Là quản lý cửa hàng, tôi muốn xem doanh thu, số đơn, số pizza và các chỉ số trung bình trong kỳ để nắm tình hình bán hàng tổng quan.

### US02 Theo dõi thời gian

Là quản lý cửa hàng, tôi muốn xem số đơn theo thứ và tháng để nhận diện các giai đoạn có lượng đơn cao hoặc thấp.

### US03 Phân tích cơ cấu

Là quản lý cửa hàng, tôi muốn xem tỷ trọng doanh thu theo danh mục và kích cỡ để hiểu cơ cấu bán hàng.

### US04 Phân tích sản phẩm

Là quản lý cửa hàng, tôi muốn xem Top và Bottom sản phẩm theo ba tiêu chí để không đánh đồng sản phẩm bán nhiều với sản phẩm tạo doanh thu cao.

### US05 Lọc báo cáo

Là người xem báo cáo, tôi muốn chọn khoảng ngày và danh mục để phân tích một phạm vi cụ thể.

### US06 Kiểm tra số liệu

Là người phân tích, tôi muốn chạy SQL trong cùng phạm vi lọc để xác nhận kết quả Power BI.

## 8. Yêu cầu chức năng và tiêu chí chấp nhận

### FR01 Hiển thị năm KPI tổng quan

Dashboard hiển thị Total Revenue, Avg Order Value, Total Pizzas Sold, Total Orders và Avg Pizzas Per Order trên cả hai trang.

Tiêu chí chấp nhận:

- Công thức khớp A1–A5.
- Total Orders dùng `COUNT(DISTINCT order_id)`.
- Total Pizzas Sold dùng `SUM(quantity)`.
- Hai giá trị trung bình giữ hai chữ số thập phân.
- Khi không có đơn, hai giá trị trung bình để trống thay vì báo lỗi.

Truy vết: A1–A5 → TC01 đến TC05.

### FR02 Hiển thị số đơn theo thứ

Biểu đồ Daily Trend hiển thị số đơn của từng thứ.

Tiêu chí chấp nhận:

- Dùng số đơn duy nhất, không dùng số dòng.
- Thứ tự từ Monday đến Sunday.
- Giá trị khớp B trong cùng phạm vi lọc.
- Không kết luận giờ cao điểm từ biểu đồ này.

Truy vết: B → TC06.

### FR03 Hiển thị số đơn theo tháng

Biểu đồ Monthly Trend hiển thị số đơn theo thời gian.

Tiêu chí chấp nhận:

- Tháng được sắp theo thời gian.
- Năm và tháng được giữ cùng nhau để dữ liệu nhiều năm không bị gộp sai.
- Giá trị khớp C.
- Nhận xét tĩnh phải phản ánh đúng kết quả đang hiển thị.

Truy vết: C → TC07 và TC18.

### FR04 Hiển thị cơ cấu doanh thu

Dashboard hiển thị tỷ trọng doanh thu theo danh mục và kích cỡ.

Tiêu chí chấp nhận:

- Tử số là doanh thu của nhóm.
- Mẫu số là tổng doanh thu trong cùng phạm vi lọc.
- Mọi nhóm có dữ liệu được hiển thị.
- Tổng phần trăm có thể lệch tối đa do làm tròn từng nhóm.

Truy vết: D, E → TC08, TC09.

### FR05 Hiển thị số pizza theo danh mục

Biểu đồ hiển thị `SUM(quantity)` cho từng danh mục.

Tiêu chí chấp nhận:

- Không có điều kiện tháng cố định trong truy vấn mặc định.
- Kết quả tuân theo phạm vi ngày và danh mục đang chọn.
- Sắp xếp giảm dần theo số pizza.

Truy vết: F → TC10.

### FR06 Hiển thị Top 5 và Bottom 5 sản phẩm

Báo cáo có sáu biểu đồ theo doanh thu, số lượng và số đơn.

Tiêu chí chấp nhận:

- Doanh thu dùng `SUM(total_price)`.
- Số lượng dùng `SUM(quantity)`.
- Số đơn dùng `COUNT(DISTINCT order_id)`.
- Mỗi biểu đồ hiển thị tối đa 5 sản phẩm.
- Khi giá trị bằng nhau, dùng `pizza_name` tăng dần làm tiêu chí phụ để kết quả ổn định.
- Xếp hạng được tính lại trong phạm vi bộ lọc hiện tại.

Truy vết: G đến L → TC11 đến TC13 và TC19.

### FR07 Lọc theo ngày và danh mục

Người xem có thể chọn khoảng ngày và một danh mục.

Tiêu chí chấp nhận:

- Ngày bắt đầu và ngày kết thúc đều được bao gồm.
- KPI và biểu đồ trên trang dùng cùng phạm vi.
- Khi chuyển trang, bộ lọc phải giữ nguyên nếu báo cáo được thiết kế đồng bộ slicer.
- Xóa bộ lọc khôi phục kết quả toàn kỳ.

Truy vết: A–L → TC14 đến TC16.

### FR08 Trình bày báo cáo rõ ràng

Tiêu chí chấp nhận:

- Tiêu đề mô tả đúng nội dung biểu đồ.
- Tên sản phẩm quan trọng đọc được, không bị cắt gây nhầm lẫn.
- Tooltip hiển thị tên và giá trị đầy đủ.
- Số đơn và số pizza hiển thị dạng số nguyên.
- Đơn vị tiền được ghi khi nguồn được xác nhận.
- Không giữ số liệu cũ hoặc báo lỗi ở phạm vi không có dữ liệu.

Truy vết: TC17 và TC20.

## 9. Quy tắc nghiệp vụ

### BR01 Đếm đơn

Một `order_id` có thể xuất hiện ở nhiều dòng. Tổng số đơn luôn dùng số mã đơn duy nhất.

### BR02 Tính doanh thu

Doanh thu là tổng `total_price` của các dòng thuộc phạm vi lọc. Dự án chưa có quy tắc thuế, giảm giá, hủy hoặc hoàn tiền; vì vậy không gọi chỉ số này là lợi nhuận hoặc doanh thu thuần.

### BR03 Tính giá trị đơn trung bình

Avg Order Value bằng tổng doanh thu chia số đơn duy nhất trong cùng phạm vi.

### BR04 Tính số pizza trung bình mỗi đơn

Avg Pizzas Per Order bằng tổng `quantity` chia số đơn duy nhất trong cùng phạm vi.

### BR05 Bộ lọc danh mục

Khi lọc một danh mục, số đơn là số đơn có ít nhất một dòng thuộc danh mục đó. Không cộng số đơn của các danh mục để suy ra tổng số đơn vì một đơn có thể chứa nhiều danh mục.

### BR06 Tỷ trọng doanh thu

Tỷ trọng nhóm bằng doanh thu nhóm chia tổng doanh thu sau khi áp dụng cùng bộ lọc. Khi tổng doanh thu bằng 0, tỷ trọng để trống.

### BR07 Xếp hạng

Top và Bottom trả tối đa 5 sản phẩm. `pizza_name` là tiêu chí phụ khi hai sản phẩm có cùng giá trị. SQL và Power BI phải áp dụng cùng quy tắc.

### BR08 Dữ liệu rỗng

Doanh thu, số đơn và số pizza bằng 0 khi không có dòng. Chỉ số trung bình và tỷ trọng để trống vì không có mẫu số.

### BR09 Nhận xét trên dashboard

Nhận xét tĩnh chỉ dùng cho phạm vi đã ghi rõ. Khi slicer thay đổi, nhận xét phải cập nhật theo dữ liệu hoặc được trình bày như nhận xét của kỳ toàn năm. Biểu đồ theo thứ không chứng minh kết luận về giờ trong ngày.

## 10. Yêu cầu phi chức năng

- Dashboard phải đọc được ở kích thước xem thông thường.
- Các trang dùng cách đặt tên và định dạng số nhất quán.
- Truy vấn đối chiếu không được thay đổi dữ liệu nguồn.
- Không đưa mật khẩu hoặc thông tin kết nối nhạy cảm vào repository.
- File PBIX và tài liệu phải mở được từ cấu trúc thư mục dự án.
- Quyền công khai dữ liệu đầy đủ phải được xác nhận trước khi đưa lên GitHub.

## 11. Tình trạng triển khai và kiểm thử hiện tại

Bản SQL hiện dùng từng SELECT riêng theo A–L. Các yêu cầu phía trên là tiêu chí đích, không phải xác nhận tất cả đã được triển khai.

- A1–A5: đã chạy trên dữ liệu có đơn. SUM trả số thực nhiều chữ số; khi đối chiếu tiền và AOV cần làm tròn hai chữ số.
- B, C: số đơn đã tổng hợp được nhưng không có ORDER BY; C chỉ nhóm tên tháng, chưa tách năm.
- F: giữ bộ lọc MONTH(order_date) = 2. Kết quả chỉ thuộc tháng 2; chưa đáp ứng FR05 cho toàn kỳ.
- G–L: chưa có tiêu chí phụ cho đồng hạng như BR07 yêu cầu.
- Không có biến ngày/danh mục; thêm WHERE thủ công để kiểm thử từng phạm vi. Khi tính tỷ trọng phải lọc cả tử và mẫu.
- A chưa bảo đảm quy tắc dữ liệu rỗng BR08; chưa retest tình huống rỗng.
- UAT phiên bản hiện tại: 0 Pass, 2 Fail, 1 Blocked, 17 Not Run. Fail gồm TC10 sai phạm vi và TC17 lỗi nội dung trên ảnh. Các Pass trước đây là kết quả lịch sử của bản SQL cũ.

Chi tiết và bằng chứng nằm trong UAT_Test_Cases.md và Test_Summary.md.
## 12. Ma trận truy vết tổng hợp

- KPI tổng quan: US01 → FR01 → A1–A5 → TC01–TC05.
- Xu hướng theo thứ: US02 → FR02 → B → TC06.
- Xu hướng theo tháng: US02 → FR03 → C → TC07, TC18.
- Cơ cấu doanh thu: US03 → FR04 → D, E → TC08, TC09.
- Số lượng theo danh mục: US03 → FR05 → F → TC10.
- Xếp hạng sản phẩm: US04 → FR06 → G–L → TC11–TC13, TC19.
- Bộ lọc: US05 → FR07 → A–L → TC14–TC16.
- Trình bày và dữ liệu rỗng: FR08 → TC17, TC20.

## 13. Điều kiện hoàn thành

Dự án được ghi nhận hoàn tất kiểm thử khi:

- TC10 và TC17 được sửa và retest đạt.
- TC14 đến TC16 được chạy với bằng chứng SQL và Power BI cùng phạm vi.
- TC19 và TC20 được chạy hoặc có quyết định loại khỏi phạm vi kèm lý do.
- Các test còn Not Run được chạy và có bằng chứng; không còn lỗi làm sai KPI hoặc phạm vi bộ lọc.
- Kết quả cuối cùng được cập nhật trong `04_UAT/Test_Summary.md`.

