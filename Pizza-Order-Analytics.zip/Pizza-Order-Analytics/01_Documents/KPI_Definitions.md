# Từ điển KPI và chỉ số báo cáo

Phiên bản 2.0  
Phạm vi mặc định: 01/01/2015–31/12/2015, tất cả danh mục.  
Nguồn: `dbo.pizza_sales`, mức chi tiết một dòng món trong đơn hàng.

SQL và Power BI phải áp dụng cùng khoảng ngày và danh mục. Ngày bắt đầu và ngày kết thúc đều được tính.

## KPI01 — Total Revenue

- **Ý nghĩa:** tổng giá trị bán hàng trong phạm vi đang chọn.
- **Công thức:** `SUM(total_price)`.
- **Hiển thị:** số thập phân; có thể rút gọn bằng K nhưng tooltip hoặc dữ liệu chi tiết cần giữ giá trị đầy đủ.
- **Kết quả toàn kỳ:** 817.860,05.
- **Khi không có dữ liệu:** 0.
- **Giới hạn:** chưa có quy tắc thuế, giảm giá, hủy và hoàn tiền; không gọi là lợi nhuận hoặc doanh thu thuần. Đơn vị tiền tệ chưa được xác nhận.
- **Truy vết:** FR01 → A1–A5 → TC01.

## KPI02 — Total Orders

- **Ý nghĩa:** số đơn hàng duy nhất trong phạm vi đang chọn.
- **Công thức:** `COUNT(DISTINCT order_id)`.
- **Hiển thị:** số nguyên.
- **Kết quả toàn kỳ:** 21.350 đơn.
- **Khi không có dữ liệu:** 0.
- **Quy tắc:** không dùng số dòng vì một đơn có thể chứa nhiều loại pizza.
- **Truy vết:** FR01 → A1–A5 → TC04.

## KPI03 — Total Pizzas Sold

- **Ý nghĩa:** tổng số pizza bán ra trong phạm vi đang chọn.
- **Công thức:** `SUM(quantity)`.
- **Hiển thị:** số nguyên.
- **Kết quả toàn kỳ:** 49.574 pizza.
- **Khi không có dữ liệu:** 0.
- **Truy vết:** FR01 → A1–A5 → TC03.

## KPI04 — Average Order Value

- **Ý nghĩa:** giá trị bán hàng trung bình trên một đơn duy nhất.
- **Công thức:** `Total Revenue / Total Orders`.
- **Hiển thị:** hai chữ số thập phân.
- **Kết quả toàn kỳ:** 38,31.
- **Khi không có đơn:** để trống, không trả lỗi chia cho 0.
- **Truy vết:** FR01 → A1–A5 → TC02.

## KPI05 — Average Pizzas Per Order

- **Ý nghĩa:** số pizza trung bình trong một đơn duy nhất.
- **Công thức:** `Total Pizzas Sold / Total Orders`.
- **Hiển thị:** hai chữ số thập phân.
- **Kết quả toàn kỳ:** 2,32.
- **Khi không có đơn:** để trống, không trả lỗi chia cho 0.
- **Truy vết:** FR01 → A1–A5 → TC05.

## Các chỉ số phân tích

### Số đơn theo thời gian

- Dùng `COUNT(DISTINCT order_id)`.
- Theo thứ: sắp xếp Monday đến Sunday, không sắp theo chữ cái.
- Theo tháng: giữ cả năm và tháng để không gộp cùng một tháng của nhiều năm.
- Truy vết: FR02, FR03 → B, C → TC06, TC07, TC18.

### Tỷ trọng doanh thu

- Công thức: doanh thu nhóm chia tổng doanh thu trong cùng phạm vi lọc, nhân 100.
- Áp dụng cho `pizza_category` và `pizza_size`.
- Tổng tỷ trọng có thể lệch 0,01 điểm phần trăm do làm tròn từng nhóm.
- Khi tổng doanh thu bằng 0: để trống.
- Truy vết: FR04 → D, E → TC08, TC09.

### Top 5 và Bottom 5 sản phẩm

- Theo doanh thu: `SUM(total_price)`.
- Theo số lượng: `SUM(quantity)`.
- Theo số đơn: `COUNT(DISTINCT order_id)`.
- Xếp giảm dần cho Top và tăng dần cho Bottom.
- Khi bằng nhau, sắp `pizza_name` tăng dần để kết quả ổn định.
- Xếp hạng phải tính lại sau khi áp dụng bộ lọc.
- Truy vết: FR06 → G–L → TC11–TC13, TC19.

## Trạng thái của SQL hiện tại

Các công thức và quy tắc ở trên là định nghĩa nghiệp vụ dùng để kiểm thử. Bản SQL A–L hiện chưa triển khai đầy đủ quy tắc dữ liệu rỗng, thứ tự ngày/tháng, tách năm và đồng hạng. F chỉ lấy tháng 2. A1 trả 817860.05083847046 và A2 trả 38.30726233435459 trên nguồn hiện tại; giá trị làm tròn là 817.860,05 và 38,31. Không dùng số chữ số trên màn hình để kết luận nguồn là kiểu tiền chính xác.

## Quy tắc đối chiếu

- Số đơn và số pizza: so sánh chính xác.
- Chỉ số trung bình và tỷ trọng: so sánh ở hai chữ số thập phân.
- Thẻ rút gọn bằng K: phải khớp sau làm tròn; khi nghiệm thu chính thức cần kiểm tra giá trị đầy đủ qua tooltip hoặc dữ liệu xuất.
- Một test chỉ được ghi Pass khi có kết quả mong đợi, kết quả thực tế và bằng chứng trong đúng phạm vi lọc.

