# Tổng hợp kiểm thử — SQL A–L hiện tại

## Kết quả chạy SQL

Đã chạy thành công toàn bộ 17 câu SELECT độc lập: 5 KPI ở A, 11 câu B–L và một ví dụ Classic. Bằng chứng: [Current_SQL_Results.txt](Test_Evidence/Current_SQL_Results.txt).

- Doanh thu nguyên bản: 817860.05083847046; làm tròn: 817.860,05.
- AOV nguyên bản: 38.30726233435459; làm tròn: 38,31.
- Số pizza: 49.574; số đơn: 21.350; pizza trung bình mỗi đơn: 2,32.
- F chỉ có tháng 2: Classic 1.178; Supreme 964; Veggie 944; Chicken 875.
- B/C không sắp theo thời gian. C chưa tách năm. G–L không có tiêu chí phụ cho đồng hạng.
- Chưa chạy bộ lọc kết hợp, dữ liệu rỗng hoặc dữ liệu nhiều năm trên phiên bản hiện tại.

## UAT

**0 Pass, 2 Fail, 1 Blocked, 17 Not Run** trên 20 test case.

TC10 Fail vì SQL F và dashboard toàn kỳ khác phạm vi. TC17 Fail dựa trên lỗi nội dung/nhãn của hai ảnh hiện có. TC18 Blocked do thiếu dữ liệu thử nhiều năm. Các test khác cần retest Power BI, dù đã có kết quả SQL cho nhiều mục.

Có 6 lỗi mở: 1 High, 4 Medium, 1 Low. Chi tiết trong [UAT_Test_Cases.md](UAT_Test_Cases.md). Dự án chưa hoàn tất UAT.

## Bằng chứng lịch sử

SQL_Execution_Results.md, Beginner_SQL_Results.txt và các đối chiếu trước lần thay thế là bằng chứng lịch sử; không dùng chúng để xác nhận code hiện tại đã đạt mọi yêu cầu. File UAT_Original.docx và SQL_Original.docx được giữ làm tài liệu nguồn.

