# Kịch bản UAT — phiên bản SQL A–L

Đây là tự kiểm thử dự án cá nhân. Bộ SQL hiện tại dùng từng SELECT riêng, không có tham số. Các kết quả Pass của phiên bản cũ không được chuyển tự động sang phiên bản này.

## Điều kiện và bằng chứng

- SQL Server: bảng pizza_sales trong database chứa dữ liệu dự án.
- A–E, G–L dùng toàn bộ nguồn năm 2015; F chỉ dùng tháng 2; ví dụ cuối chỉ dùng Classic.
- Bằng chứng chạy hiện tại: [Current_SQL_Results.txt](Test_Evidence/Current_SQL_Results.txt).
- Ảnh đang có: [Home](../06_Images/dashboard_overview.png), [Products](../06_Images/dashboard_products.png). Chưa có ảnh retest tương tác mới.
- Pass: đáp ứng toàn bộ tiêu chí và có bằng chứng; Fail: có sai lệch quan sát được; Blocked: thiếu điều kiện thực hiện; Not Run: chưa chạy đầy đủ cả SQL và Power BI.
- Với TC01–TC13, mặc định đối chiếu toàn năm 2015, All. TC10 kiểm tra chính sự khác biệt phạm vi của F.

## Kịch bản

### TC01 — Tổng doanh thu

- **Truy vết:** FR01 / A1.
- **Bước thực hiện:** Chạy A1 và xem thẻ doanh thu trên hai trang, cùng phạm vi toàn năm.
- **Mong đợi:** Khớp sau làm tròn hai chữ số; kiểm tra thêm giá trị đầy đủ của measure.
- **Thực tế:** SQL trả 817860.05083847046; chưa retest measure Power BI.
- **Trạng thái:** Not Run.

### TC02 — Giá trị đơn trung bình

- **Truy vết:** FR01 / A2.
- **Bước thực hiện:** Chạy A2; đối chiếu thẻ Avg Order Value.
- **Mong đợi:** 38,31 sau làm tròn hai chữ số.
- **Thực tế:** SQL trả 38.30726233435459; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC03 — Tổng pizza

- **Truy vết:** FR01 / A3.
- **Bước thực hiện:** Chạy A3; đối chiếu Total Pizzas Sold.
- **Mong đợi:** 49.574 pizza.
- **Thực tế:** SQL trả 49574; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC04 — Tổng đơn

- **Truy vết:** FR01 / A4.
- **Bước thực hiện:** Chạy A4; đối chiếu Total Orders.
- **Mong đợi:** 21.350 mã đơn duy nhất.
- **Thực tế:** SQL trả 21350; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC05 — Pizza trung bình mỗi đơn

- **Truy vết:** FR01 / A5.
- **Bước thực hiện:** Chạy A5; đối chiếu thẻ trung bình.
- **Mong đợi:** 2,32.
- **Thực tế:** SQL trả 2.32; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC06 — Xu hướng theo thứ

- **Truy vết:** FR02 / B.
- **Bước thực hiện:** Chạy B; so từng thứ với biểu đồ, kiểm tra thứ tự.
- **Mong đợi:** Số đơn theo từng thứ khớp; biểu đồ sắp theo FR02.
- **Thực tế:** B trả đủ 7 thứ nhưng không có ORDER BY; chưa retest biểu đồ.
- **Trạng thái:** Not Run.

### TC07 — Xu hướng theo tháng

- **Truy vết:** FR03 / C.
- **Bước thực hiện:** Chạy C; so 12 tháng bằng tên tháng, không dựa vào vị trí dòng.
- **Mong đợi:** July 1.935, May 1.853; biểu đồ sắp theo thời gian.
- **Thực tế:** C trả đủ 12 tháng không theo thứ tự; chưa retest biểu đồ.
- **Trạng thái:** Not Run.

### TC08 — Tỷ trọng danh mục

- **Truy vết:** FR04 / D.
- **Bước thực hiện:** Chạy D; so từng nhãn danh mục và tỷ trọng.
- **Mong đợi:** Classic 26,91%; Supreme 25,46%; Chicken 23,96%; Veggie 23,68%.
- **Thực tế:** SQL khớp mốc trên; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC09 — Tỷ trọng kích cỡ

- **Truy vết:** FR04 / E.
- **Bước thực hiện:** Chạy E; so từng kích cỡ.
- **Mong đợi:** L 45,89%; M 30,49%; S 21,77%; XL 1,72%; XXL 0,12%.
- **Thực tế:** SQL khớp mốc trên; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC10 — Số pizza theo danh mục toàn kỳ

- **Truy vết:** FR05 / F.
- **Bước thực hiện:** Chạy F nguyên trạng; so phạm vi với dashboard toàn năm.
- **Mong đợi:** Nguồn đối chiếu cùng phạm vi toàn năm của dashboard.
- **Thực tế:** F chỉ lấy tháng 2: Classic 1.178; Supreme 964; Veggie 944; Chicken 875. Không cùng phạm vi với ảnh toàn năm.
- **Trạng thái:** Fail.

### TC11 — Top/Bottom doanh thu

- **Truy vết:** FR06 / G, H.
- **Bước thực hiện:** Chạy G, H; so tên sản phẩm đầy đủ và giá trị trên Power BI.
- **Mong đợi:** Thai Chicken cao nhất 43.434,25; Brie Carre thấp nhất 11.588,50 sau làm tròn.
- **Thực tế:** SQL trả các giá trị phù hợp; chưa retest đủ tên qua tooltip.
- **Trạng thái:** Not Run.

### TC12 — Top/Bottom số lượng

- **Truy vết:** FR06 / I, J.
- **Bước thực hiện:** Chạy I, J; so tập sản phẩm và số lượng.
- **Mong đợi:** Classic Deluxe 2.453; Brie Carre 490.
- **Thực tế:** SQL trả đúng mốc; chưa retest Power BI.
- **Trạng thái:** Not Run.

### TC13 — Top/Bottom số đơn

- **Truy vết:** FR06 / K, L.
- **Bước thực hiện:** Chạy K, L; so tập sản phẩm và số đơn.
- **Mong đợi:** Classic Deluxe 2.329; Brie Carre 480.
- **Thực tế:** SQL trả đúng mốc; thứ tự hai sản phẩm cùng 918 đơn chưa được quy định.
- **Trạng thái:** Not Run.

### TC14 — Lọc ngày

- **Truy vết:** FR07 / A–L.
- **Bước thực hiện:** Tạo bản truy vấn thử với WHERE từ 20150201 đến trước 20150301; chọn cùng phạm vi trên Power BI.
- **Mong đợi:** Các KPI và biểu đồ cùng phạm vi; mẫu số tỷ trọng cũng được lọc.
- **Thực tế:** Chưa chạy lại trên bản SQL hiện tại và slicer Power BI.
- **Trạng thái:** Not Run.

### TC15 — Lọc ngày và danh mục

- **Truy vết:** FR07 / A–L.
- **Bước thực hiện:** Thêm WHERE tháng 2/2015 và Classic trước GROUP BY; lọc cả mẫu số ở D/E; so Power BI.
- **Mong đợi:** Tất cả kết quả dùng cùng ngày và danh mục.
- **Thực tế:** Ví dụ cuối file chỉ lọc Classic toàn kỳ; không thay thế test này.
- **Trạng thái:** Not Run.

### TC16 — Giữ và xóa bộ lọc

- **Truy vết:** FR07.
- **Bước thực hiện:** Đặt bộ lọc, chuyển trang, xóa bộ lọc.
- **Mong đợi:** Bộ lọc đồng bộ giữa hai trang và trở lại toàn kỳ khi xóa.
- **Thực tế:** Chưa thao tác trực tiếp.
- **Trạng thái:** Not Run.

### TC17 — Nội dung và khả năng đọc

- **Truy vết:** FR08.
- **Bước thực hiện:** Rà hai ảnh dashboard hiện có, đối chiếu nội dung với SQL.
- **Mong đợi:** Nhận xét đúng, tiêu đề đúng khu vực, tên sản phẩm rõ.
- **Thực tế:** Vẫn có sai tháng January/May, từ evenings thiếu bằng chứng, sai tiêu đề khu vực, tên bị cắt, đơn vị tiền chưa rõ.
- **Trạng thái:** Fail.

### TC18 — Nhiều năm

- **Truy vết:** FR03 / C.
- **Bước thực hiện:** Dùng bản dữ liệu thử có cùng tháng của hai năm; kiểm tra SQL và Power BI.
- **Mong đợi:** Không gộp hai năm.
- **Thực tế:** Nguồn hiện chỉ có 2015; C đang nhóm tên tháng nên chưa đáp ứng thiết kế cho nhiều năm.
- **Trạng thái:** Blocked.

### TC19 — Đồng hạng và dưới 5 sản phẩm

- **Truy vết:** FR06 / G–L.
- **Bước thực hiện:** Dùng dữ liệu thử đồng hạng ở vị trí 5 và phạm vi dưới 5 sản phẩm.
- **Mong đợi:** Tối đa 5 sản phẩm và tiêu chí phụ theo BR07.
- **Thực tế:** SQL hiện không sắp thêm pizza_name; chưa chạy dữ liệu thử.
- **Trạng thái:** Not Run.

### TC20 — Không có dữ liệu

- **Truy vết:** FR01, FR08 / A–L.
- **Bước thực hiện:** Thêm WHERE phạm vi không có dữ liệu trên bản thử; chọn cùng phạm vi Power BI.
- **Mong đợi:** Tổng bằng 0, trung bình trống, không chia cho 0.
- **Thực tế:** Chưa chạy lại; bản hiện tại không có COALESCE/NULLIF nên chưa bảo đảm yêu cầu.
- **Trạng thái:** Not Run.

## Các lỗi đang mở

- DEF01 — Medium: textbox ghi January thay vì May; sửa nhận xét tháng và retest TC17.
- DEF02 — Medium: từ “evenings” không có phân tích giờ hỗ trợ; bỏ từ này hoặc bổ sung phân tích.
- DEF03 — Low: tiêu đề phần danh mục/kích cỡ dùng “BUSIEST DAYS & TIMES”; sửa đúng nội dung.
- DEF04 — Medium: tên sản phẩm bị cắt; tăng vùng nhãn hoặc xác nhận tooltip đầy đủ.
- DEF05 — Medium: đơn vị tiền chưa rõ; xác minh nguồn trước khi gán ký hiệu.
- DEF06 — High: F chỉ lấy tháng 2 trong khi FR05/ảnh dashboard dùng toàn năm. Cần thống nhất phạm vi và retest TC10.

Các khoảng trống thiết kế khác: B/C thiếu thứ tự; C chưa tách năm; G–L chưa có tiêu chí phụ; A chưa xử lý dữ liệu rỗng. Đây là kết quả rà code, chưa coi là các test tương tác đã chạy.

## Kết luận

20 test: **0 Pass, 2 Fail, 1 Blocked, 17 Not Run**. Chạy SQL thành công không đồng nghĩa hoàn tất UAT. Các dòng Not Run có thể đã có kết quả SQL, nhưng còn thiếu phần Power BI.

Cần xử lý TC10/TC17, chạy các test còn lại, lưu bằng chứng theo phạm vi và ghi quyết định về TC18 trước khi nghiệm thu.

