> Bằng chứng lịch sử trước khi thay SQL bằng bản A–L hiện tại. Dùng để tham khảo số liệu nguồn; không phải xác nhận UAT cho phiên bản hiện tại. Xem Current_SQL_Results.txt và Test_Summary.md.

# Đối chiếu KPI ngày 28 tháng 9 năm 2026

Nguồn xác nhận trực tiếp trong Power Query: SQL Server LONG\SQLEXPRESS, database Pizza DB, bảng dbo.pizza_sales.

Truy vấn SELECT đã thực thi trên cơ sở dữ liệu nguồn, không thay đổi dữ liệu.

- Số dòng: 48.620.
- Ngày đầu: 2015-01-01.
- Ngày cuối: 2015-12-31.
- Doanh thu: 817860.0500. Dashboard hiển thị 817.86K, khớp sau rút gọn; chưa kiểm tra giá trị đầy đủ của measure.
- Số đơn: 21.350. Khớp dashboard.
- Số pizza: 49.574. Khớp dashboard.
- Giá trị đơn trung bình: 38,31. Khớp ở 2 chữ số thập phân.
- Số pizza trung bình mỗi đơn: 2,32. Khớp ở 2 chữ số thập phân.

Phạm vi dashboard đối chiếu: toàn năm 2015, danh mục All. Kết quả xác nhận đối chiếu 5 KPI tại phạm vi này; chưa xác nhận toàn bộ UAT, tương tác bộ lọc, refresh hoặc công thức DAX.

Truy vấn đã chạy:
```sql
SELECT COUNT(*) AS Data_Rows,
 MIN(order_date) AS First_Date, MAX(order_date) AS Last_Date,
 SUM(CAST(total_price AS decimal(19,4))) AS Revenue,
 COUNT(DISTINCT order_id) AS Orders, SUM(quantity) AS Pizzas,
 CAST(SUM(CAST(total_price AS decimal(19,4))) /
 COUNT(DISTINCT order_id) AS decimal(19,2)) AS AOV,
 CAST(SUM(quantity)*1.0/COUNT(DISTINCT order_id)
 AS decimal(19,2)) AS Pizzas_Per_Order
FROM dbo.pizza_sales;
```

