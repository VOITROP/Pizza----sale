> Bằng chứng lịch sử trước khi thay SQL bằng bản A–L hiện tại. Dùng để tham khảo số liệu nguồn; không phải xác nhận UAT cho phiên bản hiện tại. Xem Current_SQL_Results.txt và Test_Summary.md.

# Số liệu cho ba nhận xét kinh doanh

Đã truy vấn ngày 28 tháng 9 năm 2026 từ dbo.pizza_sales trong Pizza DB. Phạm vi toàn bộ dữ liệu, năm 2015. Truy vấn chỉ đọc, không thay đổi dữ liệu nguồn.

## Kết quả

- Số đơn theo tháng, tháng 1 đến 12: 1845, 1685, 1840, 1799, 1853, 1773, 1935, 1841, 1661, 1646, 1792, 1680.
- Classic: 220053.10; tỷ trọng 26.91%.
- Supreme: 208197.00; tỷ trọng 25.46%.
- Chicken: 195919.50; tỷ trọng 23.96%.
- Veggie: 193690.45; tỷ trọng 23.68%.
- Sản phẩm cao nhất theo doanh thu: The Thai Chicken Pizza, 43434.25.
- Sản phẩm cao nhất theo số lượng: The Classic Deluxe Pizza, 2453.
- Chênh lệch tháng 7 với tháng 10: 1935 - 1646 = 289; 289 / 1646 × 100 = 17.56% sau làm tròn.

## SQL đã thực thi

```sql
SELECT MONTH(order_date) AS Month_Number,
 COUNT(DISTINCT order_id) AS Orders
FROM dbo.pizza_sales
GROUP BY MONTH(order_date) ORDER BY Orders DESC;

SELECT pizza_category,
 SUM(CAST(total_price AS decimal(19,4))) AS Revenue,
 CAST(100.0*SUM(CAST(total_price AS decimal(19,4)))/
 (SELECT SUM(CAST(total_price AS decimal(19,4))) FROM dbo.pizza_sales)
 AS decimal(10,2)) AS Share_Pct
FROM dbo.pizza_sales GROUP BY pizza_category ORDER BY Revenue DESC;

SELECT TOP 1 pizza_name,
 SUM(CAST(total_price AS decimal(19,4))) AS Revenue
FROM dbo.pizza_sales GROUP BY pizza_name ORDER BY Revenue DESC;

SELECT TOP 1 pizza_name,SUM(quantity) AS Quantity
FROM dbo.pizza_sales GROUP BY pizza_name ORDER BY Quantity DESC;
```

Đơn vị tiền tệ chưa xác nhận. Xếp hạng TOP 1 trên đây trả về một sản phẩm dẫn đầu, chưa kiểm tra có đồng hạng hay không. Kết quả không thay thế kiểm thử giao diện và tương tác Power BI.

