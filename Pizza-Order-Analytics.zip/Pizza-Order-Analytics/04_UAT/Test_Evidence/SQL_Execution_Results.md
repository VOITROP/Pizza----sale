> Bằng chứng lịch sử trước khi thay SQL bằng bản A–L hiện tại. Dùng để tham khảo số liệu nguồn; không phải xác nhận UAT cho phiên bản hiện tại. Xem Current_SQL_Results.txt và Test_Summary.md.

# Kết quả chạy SQL toàn kỳ

Ngày chạy: 28/09/2026  
Nguồn: `LONG\SQLEXPRESS`, database `Pizza DB`, bảng `dbo.pizza_sales`  
Phạm vi: 01/01/2015 đến 31/12/2015, tất cả danh mục  
Script: `03_SQL/03_business_analysis.sql`  
Kết quả: chạy thành công 12 result set, không thay đổi dữ liệu nguồn.

## Q01 Năm KPI

```text
Total Revenue             817860.05
Average Order Value           38.31
Total Pizzas Sold             49574
Total Orders                  21350
Average Pizzas Per Order       2.32
```

## Q02 Số đơn theo thứ

```text
Monday       2794
Tuesday      2973
Wednesday    3024
Thursday     3239
Friday       3538
Saturday     3158
Sunday       2624
```

## Q03 Số đơn theo tháng

```text
January      1845
February     1685
March        1840
April        1799
May          1853
June         1773
July         1935
August       1841
September    1661
October      1646
November     1792
December     1680
```

## Q04 Doanh thu theo danh mục

```text
Classic     220053.10    26.91%
Supreme     208197.00    25.46%
Chicken     195919.50    23.96%
Veggie      193690.45    23.68%
```

Tổng phần trăm hiển thị là 100.01% do làm tròn từng nhóm đến hai chữ số thập phân.

## Q05 Doanh thu theo kích cỡ

```text
L           375318.70    45.89%
M           249382.25    30.49%
S           178076.50    21.77%
XL           14076.00     1.72%
XXL           1006.60     0.12%
```

Tổng phần trăm hiển thị là 99.99% do làm tròn từng nhóm đến hai chữ số thập phân.

## Q06 Số pizza theo danh mục

```text
Classic     14888
Supreme     11987
Veggie      11649
Chicken     11050
```

## Q07 Top 5 theo doanh thu

```text
The Thai Chicken Pizza          43434.25
The Barbecue Chicken Pizza      42768.00
The California Chicken Pizza    41409.50
The Classic Deluxe Pizza        38180.50
The Spicy Italian Pizza         34831.25
```

## Q08 Bottom 5 theo doanh thu

```text
The Brie Carre Pizza            11588.50
The Green Garden Pizza          13955.75
The Spinach Supreme Pizza       15277.75
The Mediterranean Pizza        15360.50
The Spinach Pesto Pizza         15596.00
```

## Q09 Top 5 theo số lượng

```text
The Classic Deluxe Pizza        2453
The Barbecue Chicken Pizza      2432
The Hawaiian Pizza              2422
The Pepperoni Pizza             2418
The Thai Chicken Pizza          2371
```

## Q10 Bottom 5 theo số lượng

```text
The Brie Carre Pizza             490
The Mediterranean Pizza          934
The Calabrese Pizza              937
The Spinach Supreme Pizza         950
The Soppressata Pizza             961
```

## Q11 Top 5 theo số đơn

```text
The Classic Deluxe Pizza        2329
The Hawaiian Pizza              2280
The Pepperoni Pizza             2278
The Barbecue Chicken Pizza      2273
The Thai Chicken Pizza          2225
```

## Q12 Bottom 5 theo số đơn

```text
The Brie Carre Pizza             480
The Mediterranean Pizza          912
The Calabrese Pizza              918
The Spinach Supreme Pizza         918
The Chicken Pesto Pizza           938
```

## Kết luận chạy SQL

Tất cả truy vấn chạy thành công. Q01 đến Q12 trả về đúng số lượng result set và không phát sinh lỗi chia cho 0 trong phạm vi dữ liệu toàn năm. Các kết quả được dùng để đối chiếu hai ảnh dashboard trong UAT.

## Kiểm tra tham số và trường hợp biên

Script được chạy thêm với ba phạm vi:

```text
01/02/2015–28/02/2015, tất cả danh mục
12 result set | Revenue 65159.60 | Orders 1685 | AOV 38.67

01/02/2015–28/02/2015, Classic
12 result set | Revenue 17336.10 | Orders 871 | AOV 19.90

01/01/2016–31/01/2016, không có dữ liệu
12 result set | Revenue 0.00 | Orders 0 | AOV NULL
```

Kết quả xác nhận tham số ngày và danh mục hoạt động, ngày cuối được bao gồm và Q01 không chia cho 0 ở phạm vi rỗng. Phần hiển thị Power BI cho các trường hợp này vẫn cần kiểm tra riêng.

