# Ghi chú rà soát Power BI

PBIX chưa được sửa trong lần đồng bộ tài liệu này. Hai ảnh hiện có dùng phạm vi toàn năm 2015, All.

## SQL hiện tại và đối chiếu

- A1–A5 trả năm KPI riêng; làm tròn tiền và AOV hai chữ số khi đối chiếu.
- B tổng hợp theo thứ, C theo tên tháng; không dựa vào thứ tự dòng SQL để so biểu đồ.
- D/E tính tỷ trọng toàn nguồn. Nếu thêm WHERE phải áp dụng cùng điều kiện cho mẫu số.
- F chỉ tính tháng 2, không so trực tiếp với funnel toàn năm.
- G–L dùng TOP 5; chưa quy định thứ tự phụ khi đồng hạng.
- Ví dụ cuối lọc Classic toàn kỳ, không phải test kết hợp ngày và danh mục.

## Nội dung cần sửa trên báo cáo

1. Đổi January thành May trong nhận xét tháng đứng thứ hai.
2. Bỏ “evenings” nếu chưa bổ sung phân tích giờ.
3. Đổi tiêu đề phần danh mục/kích cỡ cho đúng nội dung.
4. Làm rõ tên sản phẩm bị cắt và tooltip.
5. Xác minh đơn vị tiền; ghi rõ nhận xét tĩnh thuộc năm 2015.

## Retest

Mở PBIX, xác nhận nguồn; chạy từng SELECT cùng phạm vi với slicer. Kiểm tra giá trị đầy đủ của measure, lọc ngày/danh mục, chuyển trang, xóa lọc, đồng hạng, dữ liệu rỗng. Lưu bằng chứng rồi cập nhật UAT. Hiện có 0 Pass, 2 Fail, 1 Blocked, 17 Not Run cho bộ hồ sơ hiện tại.

