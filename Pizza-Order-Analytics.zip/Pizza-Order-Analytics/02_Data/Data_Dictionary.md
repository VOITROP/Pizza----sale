﻿# Từ điển dữ liệu

Nguồn: pizza_sales_excel_file.xlsx, sheet pizza_sales. Mỗi dòng là một dòng món. Tiền tệ chưa được xác nhận.

## pizza_id

Kiểu: Số nguyên. Mã dòng chi tiết; duy nhất trong file đã kiểm tra.

## order_id

Kiểu: Số nguyên. Mã đơn hàng; một đơn có thể có nhiều dòng.

## pizza_name_id

Kiểu: Văn bản. Mã biến thể pizza, có kích cỡ.

## quantity

Kiểu: Số nguyên. Số pizza trong dòng món.

## order_date

Kiểu: Ngày. Ngày đặt đơn.

## order_time

Kiểu: Giờ. Giờ đặt đơn; chưa dùng trong biểu đồ hiện tại.

## unit_price

Kiểu: Số thập phân. Giá một pizza theo dữ liệu nguồn.

## total_price

Kiểu: Số thập phân. Giá trị dòng món; đối chiếu quantity × unit_price.

## pizza_size

Kiểu: Văn bản. Kích cỡ gốc S, M, L, XL, XXL.

## pizza_category

Kiểu: Văn bản. Danh mục Classic, Supreme, Chicken, Veggie.

## pizza_ingredients

Kiểu: Văn bản. Danh sách nguyên liệu.

## pizza_name

Kiểu: Văn bản. Tên loại pizza; dùng để nhóm sản phẩm.

## Dữ liệu mẫu

sample_data.csv gồm toàn bộ dòng của 100 đơn đầu tiên, không phải dữ liệu để tái tạo KPI toàn năm. File Excel đầy đủ dùng để tái tạo kết quả.

## Nguồn và quyền sử dụng

File do người thực hiện cung cấp. Chưa có đường dẫn nguồn công khai hoặc giấy phép kèm theo. Xác nhận quyền sử dụng trước khi đưa dữ liệu đầy đủ lên kho công khai.
