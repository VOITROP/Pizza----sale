# Cách chạy SQL

1. Chọn database chứa bảng pizza_sales trong SQL Server.
2. Mở 03_business_analysis.sql.
3. Bôi đen câu SELECT cần chạy rồi nhấn Execute.

File gồm A1–A5 (5 KPI), B–L (11 truy vấn) và một ví dụ Bottom 5 của Classic. Toàn bộ 17 SELECT đã chạy thành công; xem ../04_UAT/Test_Evidence/Current_SQL_Results.txt.

Đã thống nhất tên cột Avg_Order_Value, Total_Pizzas_Sold, Total_Orders, Total_Revenue, Avg_Pizzas_Per_Order và Revenue_Percent. Tiêu đề B ghi rõ phân tích theo thứ; F ghi rõ February only. Giữ nguyên logic do chủ dự án cung cấp.

F chỉ lấy tháng 2. B/C chưa sắp theo thời gian; C nhóm tên tháng chưa tách năm. Top/Bottom chưa có tiêu chí phụ. Các quy tắc dữ liệu rỗng trong tài liệu nghiệp vụ là yêu cầu cần hoàn thiện.

Nếu thêm WHERE vào tỷ trọng D/E, phải lọc cả tử số và mẫu số. Không dùng ví dụ Classic cuối file để thay thế test lọc kết hợp ngày/danh mục.

01_data_quality.sql và 02_data_cleaning.sql là các script hỗ trợ kiểm tra/chuẩn hóa, không phải bản thay thế truy vấn A–L. SQL_Original.docx và UAT_Original.docx là tài liệu nguồn lưu nguyên trạng. Bằng chứng Beginner_SQL_Results.txt là lịch sử của file SQL đã xóa; không phải kết quả hiện tại.
