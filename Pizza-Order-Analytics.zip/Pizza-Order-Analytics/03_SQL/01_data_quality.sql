﻿-- SQL Server: select the Pizza DB database first. Read-only.
-- Q00: source diagnostics, before filtering. Investigate; do not auto-delete.
SELECT COUNT_BIG(*) AS Source_Rows, MIN(order_date) AS Min_Date,
 MAX(order_date) AS Max_Date,
 SUM(CASE WHEN order_id IS NULL OR order_date IS NULL
  OR pizza_name IS NULL OR pizza_category IS NULL OR pizza_size IS NULL
  OR quantity IS NULL OR total_price IS NULL THEN 1 ELSE 0 END) AS Rows_With_Nulls,
 SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END) AS Nonpositive_Quantity,
 SUM(CASE WHEN total_price < 0 THEN 1 ELSE 0 END) AS Negative_Amount
FROM dbo.pizza_sales;
SELECT pizza_category, pizza_size, COUNT_BIG(*) AS Rows_In_Group
FROM dbo.pizza_sales GROUP BY pizza_category,pizza_size;
SELECT order_id,COUNT(DISTINCT CAST(order_date AS date)) AS Distinct_Dates
FROM dbo.pizza_sales GROUP BY order_id
HAVING COUNT(DISTINCT CAST(order_date AS date)) > 1;
-- These may be legitimate repeated items; a line key is needed to resolve them.
SELECT order_id,order_date,pizza_name,pizza_category,pizza_size,quantity,total_price,
 COUNT_BIG(*) AS Repeated_Rows
FROM dbo.pizza_sales
GROUP BY order_id,order_date,pizza_name,pizza_category,pizza_size,quantity,total_price
HAVING COUNT_BIG(*) > 1;


-- Check line-key uniqueness and row arithmetic.
SELECT pizza_id, COUNT(*) AS n FROM dbo.pizza_sales GROUP BY pizza_id HAVING COUNT(*) > 1;
SELECT COUNT(*) AS Amount_Mismatches FROM dbo.pizza_sales
WHERE ABS(CAST(total_price AS decimal(19,4)) - CAST(unit_price AS decimal(19,4))*quantity) > 0.005;
