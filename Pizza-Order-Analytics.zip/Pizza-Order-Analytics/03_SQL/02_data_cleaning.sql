﻿-- SQL Server: read-only preparation example; source data is not overwritten.
-- Excel checks found no missing values or duplicate pizza_id. No rows are deleted.
-- Exact-value mapping prevents accidental substring replacements.
SELECT pizza_id, order_id, pizza_name_id, quantity, CAST(order_date AS date) AS order_date,
 order_time, CAST(unit_price AS decimal(19,2)) AS unit_price,
 CAST(total_price AS decimal(19,2)) AS total_price,
 CASE pizza_size WHEN 'S' THEN 'Regular' WHEN 'M' THEN 'Medium'
 WHEN 'L' THEN 'Large' WHEN 'XL' THEN 'X-Large' WHEN 'XXL' THEN 'XX-Large'
 ELSE pizza_size END AS pizza_size_label,
 pizza_size AS pizza_size_source, pizza_category, pizza_ingredients, pizza_name
FROM dbo.pizza_sales;
-- This query is a reproducible preparation proposal, not proof the PBIX was modified.
